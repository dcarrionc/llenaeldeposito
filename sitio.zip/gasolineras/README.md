# Web de gasolineras baratas (España)

Web estática que se regenera sola cada hora con los **precios oficiales** del Ministerio para la Transición Ecológica: una página por cada municipio con gasolineras (~3.500), una por provincia y una portada con buscador. Sin servidor, sin base de datos, sin coste de alojamiento.

## Qué incluye

- **Página por municipio** (`/gasolineras-baratas/madrid/alcorcon/`): resumen de precios por carburante, ahorro por depósito, listado ordenable (más baratas, más cercanas, mejor precio/distancia), filtros "abiertas ahora" y "solo socios", mapa con precios, botón "Cómo llegar", municipios cercanos, histórico de precios y FAQ.
- **Página por provincia**: ranking de las 15 más baratas por carburante y tabla de municipios filtrable.
- **Portada**: buscador con autocompletado, "Usar mi ubicación", medias nacionales, ranking de provincias.
- **SEO**: HTML generado en servidor, `canonical`, `sitemap.xml`, datos estructurados (BreadcrumbList, FAQPage), títulos y descripciones con precios del día.
- **Rendimiento**: sin frameworks (≈15 KB de JS sin comprimir), Leaflet solo se carga al abrir el mapa y los anuncios tienen la altura reservada para no provocar CLS.
- **Histórico**: cada build reaprovecha el histórico ya publicado en la web y le añade el día, así que la gráfica se va construyendo sola (120 días).

## Puesta en marcha (unos 10 minutos)

1. Crea un repositorio en GitHub y sube esta carpeta.
2. **Settings → Pages → Source: GitHub Actions.**
3. **Settings → Secrets and variables → Actions → Variables**, crea las que necesites:

| Variable | Ejemplo | Para qué |
|---|---|---|
| `SITE_NAME` | `MiGasolinera` | Nombre de la marca |
| `SITE_URL` | `https://www.midominio.es` | URL final (canonical, sitemap, histórico) |
| `CNAME` | `www.midominio.es` | Dominio propio en GitHub Pages |
| `BASE_PATH` | `/mi-repo` | Solo si publicas en `usuario.github.io/mi-repo` |
| `CONTACT_EMAIL`, `OWNER_NAME` | | Textos legales |
| `ADSENSE_CLIENT` | `ca-pub-1234567890123456` | Tu ID de editor de AdSense |
| `ADSENSE_SLOT_SIDE1` / `_SIDE2` / `_BELOWLIST` | `1234567890` | IDs de los 3 bloques de anuncios |
| `GA_ID` | `G-XXXXXXX` | Google Analytics 4 (opcional) |

4. **Actions → "Actualizar precios y publicar" → Run workflow.** A partir de ahí se ejecuta solo cada hora.

## AdSense

1. Da de alta el dominio en AdSense. Cuando pongas `ADSENSE_CLIENT`, la web genera sola el `ads.txt` y carga el script.
2. Crea 3 bloques de anuncios de display (mismo esquema que dieselogasolina): dos de tamaño fijo 300×600 para el lateral (`SIDE1` arriba, `SIDE2` abajo) y uno adaptable bajo el listado (`BELOWLIST`, se pinta a 728×280 en escritorio). Pega sus IDs en las variables.
3. **Consentimiento (obligatorio en la UE):** en AdSense ve a *Privacidad y mensajes → GDPR* y activa el mensaje con la CMP de Google. No hay que tocar código; el enlace "Preferencias de privacidad" del pie ya abre ese gestor. Si prefieres otra CMP certificada (Didomi, etc.), añade su script en `layout()` de `scripts/lib/templates.mjs`.
4. Auto ads se activa o desactiva desde el panel de AdSense.
5. Revisa y completa los textos de `/aviso-legal/`, `/privacidad/` y `/cookies/` (en `templates.mjs`).

## Desarrollo local

```bash
npm run preview          # datos de ejemplo + huecos de anuncio visibles → http://localhost:3000
node scripts/build.mjs   # build real contra la API oficial → dist/
```

Requiere Node 20 o superior. No hay dependencias que instalar.

## Estructura

```
site.config.mjs              configuración (marca, AdSense, URL…)
scripts/build.mjs            descarga datos y genera dist/
scripts/lib/data.mjs         normalización, carburantes, horarios
scripts/lib/templates.mjs    HTML de todas las páginas y de los anuncios
src/assets/app.css|app.js    diseño e interacción
.github/workflows/actualizar.yml   ejecución cada hora + despliegue
```

## Notas

- Si la API falla, el build reintenta 4 veces; si no lo consigue, se mantiene publicada la versión anterior.
- GitHub pausa los workflows programados de repositorios sin actividad durante 60 días. Haz un commit de vez en cuando o vuelve a activarlo desde Actions.
- También funciona en Netlify, Cloudflare Pages o cualquier hosting estático: comando `node scripts/build.mjs`, carpeta `dist`, y una tarea programada que relance el build.
- Datos: Ministerio para la Transición Ecológica y el Reto Demográfico (reutilización permitida citando la fuente, como hace el pie de página).
