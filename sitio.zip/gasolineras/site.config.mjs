// ─────────────────────────────────────────────────────────────
//  Configuración de la web. Es lo único que necesitas tocar.
//  Cualquier valor se puede sobrescribir con variables de entorno
//  (útil en GitHub Actions → Settings → Secrets and variables).
// ─────────────────────────────────────────────────────────────
const env = process.env;

export default {
  // Marca
  siteName: env.SITE_NAME || 'Llena el Depósito',
  tagline: env.SITE_TAGLINE || 'Las gasolineras más baratas de España, actualizadas cada hora',
  // URL pública final, sin barra al final (para canonical, sitemap y OpenGraph)
  siteUrl: (env.SITE_URL || 'https://llenaeldeposito.es').replace(/\/$/, ''),
  // Si publicas en GitHub Pages sin dominio propio (usuario.github.io/repo) pon '/repo'
  basePath: (env.BASE_PATH || '').replace(/\/$/, ''),
  lang: 'es',
  contactEmail: env.CONTACT_EMAIL || 'contacto@example.com',
  ownerName: env.OWNER_NAME || 'Titular de la web',
  ownerNif: env.OWNER_NIF || '', // datos LSSI para el aviso legal
  ownerAddress: env.OWNER_ADDRESS || '',

  // Fuente de datos oficial (Ministerio para la Transición Ecológica y el Reto Demográfico)
  apiUrl:
    'https://sedeaplicaciones.minetur.gob.es/ServiciosRESTCarburantes/PreciosCarburantes/EstacionesTerrestres/',

  // Google AdSense. Deja client vacío y no se pinta ningún anuncio.
  adsense: {
    client: env.ADSENSE_CLIENT || '', // p.ej. 'ca-pub-1234567890123456'
    // Mismo esquema que la web original: 2 rascacielos laterales + 1 bloque bajo el listado
    slots: {
      side1: env.ADSENSE_SLOT_SIDE1 || '', // lateral superior, 300×600
      side2: env.ADSENSE_SLOT_SIDE2 || '', // lateral inferior, 300×600
      belowList: env.ADSENSE_SLOT_BELOWLIST || '', // bajo el listado, 728×280 adaptable
    },
  },

  // Google Analytics 4 (opcional)
  gaId: env.GA_ID || '',

  // Litros para el cálculo de "ahorro por depósito"
  tankLiters: 50,
  // Días de histórico de precios que se conservan
  historyDays: 120,
};
