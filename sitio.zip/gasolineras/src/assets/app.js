/* Interacción de la web: buscador, filtros, "cerca de mí", horarios y mapa. Sin dependencias. */
(() => {
  'use strict';
  const S = window.SITE || { base: '', fuels: {}, tank: 50 };
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const fp = (n) => (n == null ? '—' : n.toFixed(3).replace('.', ','));
  const norm = (s) => s.normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9 ]/g, ' ').replace(/\s+/g, ' ').trim();
  const store = {
    get: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
    set: (k, v) => { try { localStorage.setItem(k, v); } catch {} },
  };
  const km = (a, b) => {
    const R = 6371, r = Math.PI / 180;
    const h = Math.sin(((b.lat - a.lat) * r) / 2) ** 2 + Math.cos(a.lat * r) * Math.cos(b.lat * r) * Math.sin(((b.lng - a.lng) * r) / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(h));
  };
  const fmtKm = (d) => (d < 1 ? `${Math.round(d * 1000)} m` : `${d.toFixed(d < 10 ? 1 : 0).replace('.', ',')} km`);

  // ───────── Buscador de municipios ─────────
  let index;
  const loadIndex = () => (index ||= fetch(`${S.base}/data/search.json`).then((r) => r.json()).then((l) => l.map((x) => ({ ...x, k: norm(x.n) }))));
  function search(q, list) {
    q = norm(q);
    if (!q) return [];
    const a = [], b = [];
    for (const x of list) {
      if (x.k.startsWith(q)) a.push(x);
      else if (x.k.includes(q)) b.push(x);
      if (a.length >= 8) break;
    }
    return a.concat(b).slice(0, 8);
  }
  $$('[data-search]').forEach((form) => {
    const input = $('input', form);
    const ul = $('.sugg', form);
    let res = [], act = -1;
    const render = () => {
      ul.innerHTML = res
        .map((x, i) => `<li><a href="${S.base}${x.u}" class="${i === act ? 'act' : ''}"><span>${x.n} <small>${x.p} · ${x.c} gasolineras</small></span>${x.g ? `<b>${fp(x.g)} €</b>` : ''}</a></li>`)
        .join('');
      ul.hidden = !res.length;
    };
    input.addEventListener('focus', loadIndex, { once: true });
    input.addEventListener('input', async () => { res = search(input.value, await loadIndex()); act = -1; render(); });
    input.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        act = (act + (e.key === 'ArrowDown' ? 1 : -1) + res.length) % res.length;
        render();
      } else if (e.key === 'Escape') { ul.hidden = true; }
    });
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      res = res.length ? res : search(input.value, await loadIndex());
      const x = res[Math.max(0, act)];
      if (x) location.href = S.base + x.u;
    });
    document.addEventListener('click', (e) => { if (!form.contains(e.target)) ul.hidden = true; });
  });

  // ───────── Geolocalización ─────────
  const getPos = () =>
    new Promise((ok, ko) => {
      if (!navigator.geolocation) return ko(new Error('Tu navegador no permite geolocalización'));
      navigator.geolocation.getCurrentPosition((p) => ok({ lat: p.coords.latitude, lng: p.coords.longitude }), () => ko(new Error('No hemos podido obtener tu ubicación. Revisa los permisos del navegador.')), { enableHighAccuracy: false, timeout: 10000, maximumAge: 300000 });
    });
  $$('[data-geo-home]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const txt = btn.innerHTML;
      btn.disabled = true;
      btn.lastChild.textContent = 'Localizando…';
      try {
        const [pos, list] = await Promise.all([getPos(), loadIndex()]);
        let best, bd = 1e9;
        for (const x of list) { const d = km(pos, { lat: x.la, lng: x.lo }); if (d < bd) { bd = d; best = x; } }
        sessionStorage.setItem('pos', JSON.stringify(pos));
        location.href = `${S.base}${best.u}?cerca=1`;
      } catch (e) { alertMsg(e.message); btn.innerHTML = txt; btn.disabled = false; }
    }),
  );
  function alertMsg(m) {
    let t = $('#toast');
    if (!t) { t = document.createElement('div'); t.id = 'toast'; t.setAttribute('role', 'status'); t.style.cssText = 'position:fixed;left:50%;bottom:20px;transform:translateX(-50%);background:#111;color:#fff;padding:12px 16px;border-radius:12px;z-index:99;max-width:90vw;font-size:.9rem;box-shadow:0 8px 24px rgba(0,0,0,.3)'; document.body.append(t); }
    t.textContent = m; t.hidden = false; clearTimeout(t._h); t._h = setTimeout(() => (t.hidden = true), 4500);
  }

  // ───────── Horarios ─────────
  function nowIn(tz) {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false }).formatToParts(new Date()).map((x) => [x.type, x.value]));
    const wd = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 }[p.weekday];
    return { wd, min: (+p.hour % 24) * 60 + +p.minute };
  }
  const hhmm = (m) => `${String(Math.floor((m % 1440) / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
  function openState(week, tz) {
    if (!week) return null;
    const { wd, min } = nowIn(tz);
    const today = week[wd] || [];
    const yest = week[(wd + 6) % 7] || [];
    for (const [a, b] of yest) if (b > 1440 && min < b - 1440) return { open: true, until: b - 1440 };
    for (const [a, b] of today) if (min >= a && min < b) return { open: true, until: b >= 1440 && a === 0 ? null : b };
    const next = today.filter(([a]) => a > min).sort((x, y) => x[0] - y[0])[0];
    return { open: false, from: next ? next[0] : null };
  }

  // ───────── Listado de gasolineras ─────────
  const list = $('[data-list]');
  if (list) {
    const every = +list.dataset.every || 6;
    const chunks = $$('.chunk', list);
    const cards = $$('.st', list).map((el) => ({
      el,
      id: el.id,
      p: JSON.parse(el.dataset.p),
      lat: +el.dataset.lat,
      lng: +el.dataset.lng,
      r: el.dataset.r === '1',
      b: el.dataset.b,
      week: el.dataset.h ? JSON.parse(el.dataset.h) : null,
      $price: $('[data-price]', el), $diff: $('[data-diff]', el), $box: $('.st-price', el), $rank: $('.st-rank', el),
      $open: $('[data-open]', el), $dist: $('[data-dist]', el), $fuels: $$('.st-fuels li', el),
    }));
    let map, layer;
    const tz = cards[0] && cards[0].lng < -12 ? 'Atlantic/Canary' : 'Europe/Madrid';
    const st = {
      fuel: $('input[name=fuel]:checked')?.value,
      sort: 'price',
      openNow: false,
      hidePriv: true,
      pos: null,
    };
    const pref = store.get('fuel');
    if (pref && $(`input[name=fuel][value="${pref}"]`)) { st.fuel = pref; $(`input[name=fuel][value="${pref}"]`).checked = true; }

    // estado de apertura (una vez por carga y cada minuto)
    const paintOpen = () => cards.forEach((c) => {
      c.os = openState(c.week, tz);
      if (!c.os || (c.os.open && c.os.until == null)) return;
      c.$open.innerHTML = c.os.open
        ? `<b class="ok">Abierta</b> · cierra a las ${hhmm(c.os.until)}`
        : `<b class="ko">Cerrada</b>${c.os.from != null ? ` · abre a las ${hhmm(c.os.from)}` : ''}`;
    });
    paintOpen();
    setInterval(() => { paintOpen(); if (st.openNow) apply(); }, 60000);

    function apply() {
      const f = st.fuel;
      let vis = cards.filter((c) => c.p[f] != null && !(st.hidePriv && c.r) && !(st.openNow && c.os && !c.os.open));
      const vals = vis.filter((c) => !c.r).map((c) => c.p[f]);
      const min = Math.min(...vals), max = Math.max(...vals), mean = vals.reduce((a, b) => a + b, 0) / (vals.length || 1);
      if (st.pos) vis.forEach((c) => (c.d = km(st.pos, c)));
      const by = {
        price: (a, b) => a.p[f] - b.p[f],
        dist: (a, b) => (a.d ?? 1e9) - (b.d ?? 1e9),
        // coste estimado: depósito + ida y vuelta a 6 l/100km
        value: (a, b) => (a.p[f] * S.tank + (a.d ?? 0) * 2 * 0.06 * a.p[f]) - (b.p[f] * S.tank + (b.d ?? 0) * 2 * 0.06 * b.p[f]),
        brand: (a, b) => a.b.localeCompare(b.b, 'es') || a.p[f] - b.p[f],
      }[st.sort];
      vis.sort(by);
      const shown = new Set(vis);
      cards.forEach((c) => { if (!shown.has(c)) c.el.hidden = true; });
      vis.forEach((c, i) => {
        c.el.hidden = false;
        const p = c.p[f];
        const t = max > min ? 1 + Math.min(2, Math.floor(((p - min) / (max - min)) * 3)) : 1;
        c.$box.className = `st-price t${t}`;
        c.$price.textContent = fp(p);
        const d = p - mean;
        c.$diff.textContent = Math.abs(d) < 0.0005 ? 'en la media' : `${d < 0 ? '−' : '+'}${Math.round(Math.abs(d) * 100)} cént. vs media`;
        c.$rank.textContent = i + 1;
        c.$fuels.forEach((li) => li.classList.toggle('on', li.dataset.f === f));
        c.$dist.textContent = c.d != null ? fmtKm(c.d) : '';
        c.t = t;
        const chunk = chunks[Math.min(Math.floor(i / every), chunks.length - 1)];
        chunk.append(c.el);
      });
      $('[data-empty]').hidden = vis.length > 0;
      st.vis = vis;
      if (map) drawMarkers();
    }

    $$('input[name=fuel]').forEach((r) => r.addEventListener('change', () => { st.fuel = r.value; store.set('fuel', r.value); apply(); }));
    $('[data-sort]').addEventListener('change', async (e) => {
      st.sort = e.target.value;
      if ((st.sort === 'dist' || st.sort === 'value') && !st.pos) await locate();
      apply();
    });
    $('[data-open-now]').addEventListener('change', (e) => { st.openNow = e.target.checked; apply(); });
    $('[data-public]').addEventListener('change', (e) => { st.hidePriv = e.target.checked; apply(); });
    const nearBtn = $('[data-near]');
    async function locate() {
      nearBtn.disabled = true;
      try { st.pos = await getPos(); nearBtn.setAttribute('aria-pressed', 'true'); }
      catch (e) { alertMsg(e.message); st.sort = 'price'; $('[data-sort]').value = 'price'; }
      nearBtn.disabled = false;
    }
    nearBtn.addEventListener('click', async () => {
      await locate();
      if (st.pos) { st.sort = 'value'; $('[data-sort]').value = 'value'; apply(); list.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    });
    if (new URLSearchParams(location.search).has('cerca')) {
      try { st.pos = JSON.parse(sessionStorage.getItem('pos')); } catch {}
      if (st.pos) { st.sort = 'value'; $('[data-sort]').value = 'value'; nearBtn.setAttribute('aria-pressed', 'true'); }
    }
    apply();

    // ───────── Mapa (Leaflet bajo demanda) ─────────
    const mapWrap = $('[data-map]');
    const mapBtn = $('[data-map-toggle]');
    const loadLeaflet = () =>
      window.L ? Promise.resolve() : new Promise((ok, ko) => {
        const css = document.createElement('link');
        css.rel = 'stylesheet'; css.href = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
        document.head.append(css);
        const s = document.createElement('script');
        s.src = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js'; s.onload = ok; s.onerror = ko;
        document.head.append(s);
      });
    function drawMarkers() {
      layer.clearLayers();
      const f = st.fuel;
      st.vis.forEach((c, i) => {
        const m = L.marker([c.lat, c.lng], { icon: L.divIcon({ className: '', html: `<div class="pm t${c.t}">${fp(c.p[f])}</div>`, iconSize: [0, 0] }), zIndexOffset: 1000 - i, title: c.b });
        m.on('click', () => focusCard(c));
        layer.addLayer(m);
      });
      if (st.pos) layer.addLayer(L.marker([st.pos.lat, st.pos.lng], { icon: L.divIcon({ className: '', html: '<div class="pm me">Tú</div>', iconSize: [0, 0] }) }));
    }
    async function openMap() {
      mapWrap.hidden = false;
      mapBtn.setAttribute('aria-expanded', 'true');
      if (map) return map.invalidateSize();
      try { await loadLeaflet(); } catch { alertMsg('No se pudo cargar el mapa'); return; }
      map = L.map('map', { scrollWheelZoom: false });
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap' }).addTo(map);
      layer = L.layerGroup().addTo(map);
      drawMarkers();
      map.fitBounds(L.latLngBounds(cards.map((c) => [c.lat, c.lng])).pad(0.1));
    }
    function focusCard(c) {
      $$('.st.hl').forEach((x) => x.classList.remove('hl'));
      c.el.classList.add('hl');
      c.el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    mapBtn.addEventListener('click', () => {
      if (!mapWrap.hidden) { mapWrap.hidden = true; mapBtn.setAttribute('aria-expanded', 'false'); }
      else openMap();
    });
    list.addEventListener('click', async (e) => {
      const b = e.target.closest('[data-pin]');
      if (!b) return;
      const c = cards.find((x) => x.el.contains(b));
      await openMap();
      map.setView([c.lat, c.lng], 16);
      mapWrap.scrollIntoView({ behavior: 'smooth', block: 'center' });
    });
  }

  // ───────── Pestañas, filtros y tablas ordenables ─────────
  $$('[data-tabbtn]').forEach((b) =>
    b.addEventListener('click', () => {
      const box = b.closest('.box');
      $$('[data-tabbtn]', box).forEach((x) => { x.classList.toggle('on', x === b); x.setAttribute('aria-selected', x === b); });
      $$('[data-tab]', box).forEach((p) => (p.hidden = p.dataset.tab !== b.dataset.tabbtn));
    }),
  );
  $$('[data-filter]').forEach((inp) => {
    const rows = $$(`${inp.dataset.filter} tbody tr`);
    inp.addEventListener('input', () => { const q = norm(inp.value); rows.forEach((r) => (r.hidden = q && !norm(r.textContent).includes(q))); });
  });
  $$('th[data-sortcol]').forEach((th) =>
    th.addEventListener('click', () => {
      const tb = th.closest('table').tBodies[0];
      const i = th.cellIndex;
      const num = th.dataset.sortcol === 'n';
      const dir = (th.dataset.dir = th.dataset.dir === 'asc' ? 'desc' : 'asc') === 'asc' ? 1 : -1;
      const val = (r) => { const t = r.cells[i].textContent.trim(); return num ? parseFloat(t.replace(',', '.')) || 1e9 : t; };
      [...tb.rows].sort((a, b) => (num ? val(a) - val(b) : val(a).localeCompare(val(b), 'es')) * dir).forEach((r) => tb.append(r));
    }),
  );

  // Preferencias de privacidad (CMP de Google "Privacidad y mensajes")
  $$('[data-consent]').forEach((a) =>
    a.addEventListener('click', (e) => {
      e.preventDefault();
      if (window.googlefc?.showRevocationMessage) window.googlefc.showRevocationMessage();
      else alertMsg('El gestor de consentimiento aún no está activo.');
    }),
  );
})();
