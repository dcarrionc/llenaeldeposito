// Generador estático: descarga precios oficiales y crea todas las páginas en /dist
// Uso:  node scripts/build.mjs            (descarga de la API oficial)
//       DATA_FILE=fixtures/sample.json node scripts/build.mjs   (datos locales)
import { readFileSync, writeFileSync, mkdirSync, rmSync, cpSync, existsSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import cfg from '../site.config.mjs';
import { FUELS, MAIN_FUELS, normalizeStation, slugify, parseHours, is24h, fmtPrice, avg, median, haversine } from './lib/data.mjs';
import * as T from './lib/templates.mjs';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const DIST = join(ROOT, 'dist');
const t0 = Date.now();
const FUEL = Object.fromEntries(FUELS.map((f) => [f.key, f]));

// ───────────────────────── 1. Datos ─────────────────────────
async function fetchWithRetry(url, tries = 4) {
  let lastErr;
  for (let i = 0; i < tries; i++) {
    try {
      const ctrl = new AbortController();
      const to = setTimeout(() => ctrl.abort(), 90_000);
      const res = await fetch(url, {
        signal: ctrl.signal,
        headers: { Accept: 'application/json', 'User-Agent': `${cfg.siteName} (+${cfg.siteUrl})` },
      });
      clearTimeout(to);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const j = await res.json();
      if (j.ResultadoConsulta !== 'OK' || !Array.isArray(j.ListaEESSPrecio) || j.ListaEESSPrecio.length < 1000)
        throw new Error('Respuesta incompleta de la API');
      return j;
    } catch (e) {
      lastErr = e;
      console.warn(`Intento ${i + 1} fallido: ${e.message}`);
      await new Promise((r) => setTimeout(r, 5000 * (i + 1)));
    }
  }
  throw lastErr;
}

const raw = process.env.DATA_FILE
  ? JSON.parse(readFileSync(join(ROOT, process.env.DATA_FILE), 'utf8'))
  : await fetchWithRetry(cfg.apiUrl);
const isDemo = /EJEMPLO/i.test(raw.Nota || '');

// "31/10/2026 12:05:33" → Date (hora peninsular)
const [d, m, y, hh, mi] = raw.Fecha.match(/\d+/g).map(Number);
const updatedLabel = `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}/${y} a las ${String(hh).padStart(2, '0')}:${String(mi).padStart(2, '0')}`;
const isoDate = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

const stations = raw.ListaEESSPrecio.map(normalizeStation).filter((s) => s.lat && s.lng && Object.keys(s.prices).length);
console.log(`${stations.length} gasolineras con precio (${raw.Fecha})`);

// ───────────────────────── 2. Agrupación ─────────────────────────
const provinces = new Map(); // slug → {name, slug, id, munis: Map}
for (const s of stations) {
  const pslug = slugify(s.prov);
  if (!provinces.has(pslug)) provinces.set(pslug, { name: s.prov, slug: pslug, id: s.provId, munis: new Map() });
  const P = provinces.get(pslug);
  const key = s.muniId;
  if (!P.munis.has(key)) P.munis.set(key, { name: s.muni, id: key, prov: P, stations: [] });
  P.munis.get(key).stations.push(s);
}

function stats(list) {
  const out = {};
  for (const f of FUELS) {
    const v = list.filter((s) => !s.restricted && s.prices[f.key] != null).map((s) => s.prices[f.key]);
    if (!v.length) continue;
    out[f.key] = { min: Math.min(...v), max: Math.max(...v), avg: avg(v), med: median(v), n: v.length };
  }
  return out;
}

const allMunis = [];
for (const P of provinces.values()) {
  const used = new Set();
  for (const M of P.munis.values()) {
    let slug = slugify(M.name) || `municipio-${M.id}`;
    if (used.has(slug)) slug += `-${M.id}`;
    used.add(slug);
    M.slug = slug;
    M.url = `/gasolineras-baratas/${P.slug}/${slug}/`;
    M.stats = stats(M.stations);
    M.lat = avg(M.stations.map((s) => s.lat));
    M.lng = avg(M.stations.map((s) => s.lng));
    allMunis.push(M);
  }
  P.url = `/gasolineras-baratas/${P.slug}/`;
  P.stations = [...P.munis.values()].flatMap((M) => M.stations);
  P.stats = stats(P.stations);
}
const national = stats(stations);
const provList = [...provinces.values()].sort((a, b) => a.name.localeCompare(b.name, 'es'));
console.log(`${provList.length} provincias, ${allMunis.length} municipios`);

// ───────────────────────── 3. Histórico ─────────────────────────
// Se reaprovecha el histórico publicado en la propia web (o el de la última build local).
async function loadPrev(path) {
  const local = join(DIST, path);
  if (existsSync(local)) {
    try { return JSON.parse(readFileSync(local, 'utf8')); } catch {}
  }
  if (cfg.siteUrl.includes('example.com')) return null;
  try {
    const res = await fetch(`${cfg.siteUrl}${cfg.basePath}/${path}`, { signal: AbortSignal.timeout(15000) });
    if (res.ok) return await res.json();
  } catch {}
  return null;
}
const HF = ['g95', 'gasoleoA'];
function pushHist(h, series, s) {
  // h = {dates:[], series:{key:{g95:[],gasoleoA:[]}}}
  let idx = h.dates.indexOf(isoDate);
  if (idx === -1) {
    h.dates.push(isoDate);
    idx = h.dates.length - 1;
    for (const k of Object.keys(h.series)) for (const f of HF) h.series[k][f]?.push(null);
  }
  for (const [k, st] of Object.entries(series)) {
    h.series[k] ??= Object.fromEntries(HF.map((f) => [f, Array(h.dates.length).fill(null)]));
    for (const f of HF) {
      const arr = (h.series[k][f] ??= Array(h.dates.length).fill(null));
      while (arr.length < h.dates.length) arr.push(null);
      arr[idx] = st[f] ? +st[f].avg.toFixed(3) : null;
    }
  }
  // recorte
  const extra = h.dates.length - cfg.historyDays;
  if (extra > 0) {
    h.dates.splice(0, extra);
    for (const k of Object.keys(h.series)) for (const f of HF) h.series[k][f].splice(0, extra);
  }
  return h;
}
const prevNat = (await loadPrev('data/history.json')) || { dates: [], series: {} };
const histNat = pushHist(prevNat, { es: national, ...Object.fromEntries(provList.map((P) => [P.slug, P.stats])) });
const histProv = {};
for (const P of provList) {
  const prev = (await loadPrev(`data/hist/${P.slug}.json`)) || { dates: [], series: {} };
  histProv[P.slug] = pushHist(prev, Object.fromEntries([...P.munis.values()].map((M) => [M.slug, M.stats])));
}

// ───────────────────────── 4. Salida ─────────────────────────
rmSync(DIST, { recursive: true, force: true });
mkdirSync(DIST, { recursive: true });
cpSync(join(ROOT, 'src/assets'), join(DIST, 'assets'), { recursive: true });
const out = (path, html) => {
  const file = join(DIST, path.endsWith('/') ? path + 'index.html' : path);
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, html);
};
const ctx = { cfg, updatedLabel, isoDate, isDemo, FUEL, FUELS, MAIN_FUELS, fmtPrice };

// Datos públicos
out('data/history.json', JSON.stringify(histNat));
for (const [slug, h] of Object.entries(histProv)) out(`data/hist/${slug}.json`, JSON.stringify(h));
out(
  'data/search.json',
  JSON.stringify(
    allMunis
      .map((M) => ({
        n: M.name,
        p: M.prov.name,
        u: M.url,
        c: M.stations.length,
        la: +M.lat.toFixed(4),
        lo: +M.lng.toFixed(4),
        g: M.stats.g95 ? +M.stats.g95.min.toFixed(3) : null,
        d: M.stats.gasoleoA ? +M.stats.gasoleoA.min.toFixed(3) : null,
      }))
      .sort((a, b) => b.c - a.c),
  ),
);

// Municipios
const stationView = (s) => ({
  s,
  h24: is24h(s.hours),
  week: parseHours(s.hours),
});
for (const M of allMunis) {
  const near = allMunis
    .filter((o) => o !== M)
    .map((o) => ({ o, km: haversine(M, o) }))
    .filter((x) => x.km < 30)
    .sort((a, b) => a.km - b.km)
    .slice(0, 10);
  out(M.url, T.muniPage({ ...ctx, M, P: M.prov, views: M.stations.map(stationView), near, hist: histProv[M.prov.slug], hasSeries: true }));
}
// Provincias
for (const P of provList) {
  const munis = [...P.munis.values()].sort((a, b) => b.stations.length - a.stations.length);
  out(P.url, T.provPage({ ...ctx, P, munis, views: P.stations.map(stationView), hist: histNat }));
}
// Portada y páginas fijas
const topMunis = [...allMunis].sort((a, b) => b.stations.length - a.stations.length).slice(0, 24);
out('/', T.homePage({ ...ctx, national, provList, topMunis, hist: histNat, total: stations.length, nMunis: allMunis.length }));
const { GUIDES } = await import('./lib/guides.mjs');
out('/guias/', T.guidesIndex({ ...ctx, national }));
for (const guide of GUIDES) out(`/guias/${guide.slug}/`, T.guidePage({ ...ctx, guide, national, hist: histNat }));
out('/quienes-somos/', T.aboutPage({ ...ctx, national, hist: histNat }));
out('/privacidad/', T.legalPage({ ...ctx, kind: 'privacidad' }));
out('/cookies/', T.legalPage({ ...ctx, kind: 'cookies' }));
out('/aviso-legal/', T.legalPage({ ...ctx, kind: 'aviso-legal' }));
out('/404.html', T.notFoundPage(ctx));

// SEO / AdSense
const urls = ['/', '/guias/', '/quienes-somos/', ...GUIDES.map((g) => `/guias/${g.slug}/`), ...provList.map((P) => P.url), ...allMunis.map((M) => M.url)];
out(
  'sitemap.xml',
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls
    .map((u) => `<url><loc>${cfg.siteUrl}${cfg.basePath}${u}</loc><lastmod>${isoDate}</lastmod><changefreq>hourly</changefreq></url>`)
    .join('\n')}\n</urlset>\n`,
);
out('robots.txt', `User-agent: *\nAllow: /\n${isDemo ? 'Disallow: /\n' : ''}\nSitemap: ${cfg.siteUrl}${cfg.basePath}/sitemap.xml\n`);
if (cfg.adsense.client) out('ads.txt', `google.com, ${cfg.adsense.client.replace('ca-', '')}, DIRECT, f08c47fec0942fa0\n`);
if (process.env.CNAME) out('CNAME', process.env.CNAME + '\n');
out('.nojekyll', '');

console.log(`✓ ${urls.length + 5} páginas en ${((Date.now() - t0) / 1000).toFixed(1)}s → dist/`);
