// Genera datos de EJEMPLO con el mismo formato que la API oficial,
// solo para previsualizar el diseño sin conexión. No son precios reales.
import { writeFileSync, mkdirSync } from 'node:fs';

let seed = 42;
const rnd = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
const pick = (a) => a[Math.floor(rnd() * a.length)];
const brands = ['SURTIDOR NORTE', 'PETROSUR', 'GASÓLEOS CENTRO', 'LOWCOST FUEL', 'AUTOSERVICIO 24', 'ENERGÍA VIVA', 'BP-DEMO', 'COOP. AGRARIA', 'RUTA 5', 'ECOFUEL'];
const streets = ['AVENIDA DE LOS CASTILLOS', 'CALLE MAYOR', 'CARRETERA M-506 KM 3', 'AVENIDA DE EUROPA', 'CALLE INDUSTRIA', 'POLÍGONO URTINSA', 'AVENIDA DEL OESTE', 'PASEO DE LA ESTACIÓN', 'CALLE LIBERTAD', 'AUTOVÍA A-5 KM 14'];
const hours = ['L-D: 24H', 'L-D: 24H', 'L-D: 06:00-23:00', 'L-V: 07:00-22:00; S: 08:00-15:00', 'L-S: 07:00-21:30; D: 09:00-14:00', 'L-D: 07:00-23:00'];
const munis = [
  ['MADRID', '28', 'Alcorcón', 40.345, -3.824, 16],
  ['MADRID', '28', 'Móstoles', 40.322, -3.865, 18],
  ['MADRID', '28', 'Leganés', 40.327, -3.763, 14],
  ['MADRID', '28', 'Fuenlabrada', 40.284, -3.794, 17],
  ['MADRID', '28', 'Getafe', 40.305, -3.732, 15],
  ['MADRID', '28', 'Madrid', 40.4168, -3.7038, 40],
  ['MADRID', '28', 'Villaviciosa de Odón', 40.357, -3.900, 5],
  ['MADRID', '28', 'Boadilla del Monte', 40.405, -3.878, 6],
  ['TOLEDO', '45', 'Toledo', 39.862, -4.027, 12],
  ['TOLEDO', '45', 'Talavera de la Reina', 39.963, -4.830, 10],
  ['TOLEDO', '45', 'Illescas', 40.122, -3.848, 6],
  ['BARCELONA', '08', 'Barcelona', 41.387, 2.170, 25],
  ['BARCELONA', '08', "Hospitalet de Llobregat (L')", 41.359, 2.100, 9],
  ['CORUÑA (A)', '15', 'Coruña (A)', 43.362, -8.411, 11],
];
const L = [];
let id = 10000;
const c = (n) => n.toFixed(3).replace('.', ',');
for (const [prov, provId, muni, lat, lng, n] of munis) {
  const base = prov === 'BARCELONA' ? 0.04 : prov === 'TOLEDO' ? -0.02 : 0;
  for (let i = 0; i < n; i++) {
    const cheap = rnd() < 0.25 ? -0.09 : 0;
    const g95 = 1.47 + base + cheap + rnd() * 0.16;
    const dsl = g95 - 0.06 + rnd() * 0.05;
    const row = {
      'C.P.': '28' + String(900 + i).padStart(3, '0'),
      'Dirección': `${pick(streets)}, ${Math.ceil(rnd() * 120)}`,
      'Horario': pick(hours),
      'Latitud': (lat + (rnd() - 0.5) * 0.05).toFixed(6).replace('.', ','),
      'Localidad': muni.toUpperCase(),
      'Longitud (WGS84)': (lng + (rnd() - 0.5) * 0.06).toFixed(6).replace('.', ','),
      'Margen': 'D',
      'Municipio': muni,
      'Precio Gasoleo A': c(dsl),
      'Precio Gasoleo Premium': rnd() < 0.7 ? c(dsl + 0.07 + rnd() * 0.04) : '',
      'Precio Gasolina 95 E5': rnd() < 0.97 ? c(g95) : '',
      'Precio Gasolina 98 E5': rnd() < 0.75 ? c(g95 + 0.11 + rnd() * 0.05) : '',
      'Precio Gases licuados del petróleo': rnd() < 0.2 ? c(0.89 + rnd() * 0.12) : '',
      'Precio Adblue': rnd() < 0.3 ? c(0.79 + rnd() * 0.4) : '',
      'Provincia': prov,
      'Remisión': 'dm',
      'Rótulo': pick(brands),
      'Tipo Venta': rnd() < 0.05 ? 'R' : 'P',
      'IDEESS': String(id++),
      'IDMunicipio': String(4000 + munis.indexOf(munis.find((m) => m[2] === muni))),
      'IDProvincia': provId,
      'IDCCAA': '13',
    };
    L.push(row);
  }
}
const now = new Date();
const p2 = (x) => String(x).padStart(2, '0');
const fecha = `${p2(now.getDate())}/${p2(now.getMonth() + 1)}/${now.getFullYear()} ${p2(now.getHours())}:${p2(now.getMinutes())}:00`;
mkdirSync('fixtures', { recursive: true });
writeFileSync('fixtures/sample.json', JSON.stringify({ Fecha: fecha, ListaEESSPrecio: L, Nota: 'DATOS DE EJEMPLO', ResultadoConsulta: 'OK' }));
console.log(`fixtures/sample.json → ${L.length} estaciones de ejemplo`);
